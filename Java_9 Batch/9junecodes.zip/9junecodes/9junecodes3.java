

class home {

	public static void main(String[ ] args) {

		float f = 20.22f;

		System.out.println(f);

		double g = 20.22;
		
		System.out.println(g);

		if(f == g)
			System.out.println("same value");
		else
			System.out.println("different value");



	}

}
