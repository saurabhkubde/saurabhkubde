

class man {

	public static void main(String[] args) {

		char str = 'a';
		char ch=65;
		char m=49;

		System.out.println(str);
		System.out.println(ch);
		System.out.println(m);


	}


}
