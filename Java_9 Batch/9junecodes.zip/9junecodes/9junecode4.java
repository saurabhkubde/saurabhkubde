
class virus {

	
	
	public static void main(String[] args) {

		byte a=127;
		System.out.println(a);
		a++;
		System.out.println(a);
		a++;
		System.out.println(a);
	}

}
