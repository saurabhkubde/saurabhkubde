
class virus {



	public static void main(String[] args) {

		short vaccine=32767;
		System.out.println(vaccine);
		vaccine++;
		System.out.println(vaccine);
		vaccine++;
		System.out.println(vaccine);
	}

}
