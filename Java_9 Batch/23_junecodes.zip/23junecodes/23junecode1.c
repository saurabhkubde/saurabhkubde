#include<stdio.h>



	void main (int argc,char* argv[]) {

		printf("%s\n",argv[0]);
		printf("%s\n",argv[1]);
		printf("%s\n",argv[2]);
		printf("%s\n",argv[3]);
	}


